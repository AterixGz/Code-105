export default {
    companyName: 'ร้านมือถือ 702NUMBER เลขที่ 702 ถ.ลูกรัง แขวงเสื้อ เขตพิสดุโลก กทม 10100 เลขที่ 09348593485',
    buyerName: 'บ.เบ็กแฟนคลับ จก. 207 ถ.xxx แขวงxx',
    datebill: '26/7/60',
    companyAddress: 'เขตxxx จ.กทม 10600',
    commercialLicense: '09673987398',
    collector: '________ร้านมือถือ 702________',

    items: [
        {
            quantity: `2,500`,
            description: 'แท่งไฟมหัศจรรย์ 7 สี โทรออกได้',
            eachprice: 99,
            amount: '247,500'
        },
        
    ]
}
